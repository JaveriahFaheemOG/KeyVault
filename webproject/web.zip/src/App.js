import React from 'react';
import Homepage from './js-files/homepage';
import './App.css';
import {BrowserRouter as Router, Routes, Route} from "react-router-dom";

function App() 
{
  return (
    <Router>
    <div className="App">
      <header className="App-header">
        <Homepage/>
        <Routes>
        <Route path='./js-files/homepage' element={<Homepage/>}/>
        </Routes>
      </header>
    </div>
    </Router>
  );
}
export default App;
